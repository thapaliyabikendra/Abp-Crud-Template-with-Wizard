﻿using System;
using Volo.Abp.Application.Dtos;

namespace $rootnamespace$.$pluralentityname$;
public class $safeitemname$: AuditedEntityDto<Guid>
{
    $createupdateproperties$
}
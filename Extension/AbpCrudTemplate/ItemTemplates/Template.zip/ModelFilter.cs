﻿using System;

namespace $rootnamespace$.$pluralentityname$;
public class $safeitemname$
{$filterproperties$
}
﻿using System;
using System.ComponentModel.DataAnnotations;

namespace $rootnamespace$.$pluralentityname$;
public class $safeitemname$
{$createupdateproperties$
}